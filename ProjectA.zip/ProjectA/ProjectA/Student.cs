﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectA
{
    class Student
    {
        private string FirstName;
        private string LastName;
        private string Contact;
        private string Email;
        private DateTime DateOfBirth;
        private string Gender;

        public string FirstName1
        {
            get
            {
                return FirstName;
            }

            set
            {
                FirstName = value;
            }
        }

        public string LastName1
        {
            get
            {
                return LastName;
            }

            set
            {
                LastName = value;
            }
        }

        public string Contact1
        {
            get
            {
                return Contact;
            }

            set
            {
                Contact = value;
            }
        }

        public string Email1
        {
            get
            {
                return Email;
            }

            set
            {
                Email = value;
            }
        }

        public DateTime DateOfBirth1
        {
            get
            {
                return DateOfBirth;
            }

            set
            {
                DateOfBirth = value;
            }
        }

        public string Gender1
        {
            get
            {
                return Gender;
            }

            set
            {
                Gender = value;
            }
        }
    }
}
